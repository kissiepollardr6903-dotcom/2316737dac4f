# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(flint src/flint.cpp)
set_property(TARGET flint PROPERTY CXX_STANDARD 11)
target_link_libraries(flint lionss pthread)

add_executable(fx-triangulation src/fx-triangulation.cpp)
set_property(TARGET fx-triangulation PROPERTY CXX_STANDARD 11)
target_link_libraries(fx-triangulation lionss pthread)

add_executable(crane_seq src/crane_seq.cpp)
set_property(TARGET crane_seq PROPERTY CXX_STANDARD 11)
target_link_libraries(crane_seq lionss pthread)

add_executable(fontforge-batch src/fontforge-batch.cpp)
set_property(TARGET fontforge-batch PROPERTY CXX_STANDARD 11)
target_link_libraries(fontforge-batch lionss pthread)

add_executable(ferrite src/ferrite.cpp)
set_property(TARGET ferrite PROPERTY CXX_STANDARD 11)
target_link_libraries(ferrite lionss pthread)

add_executable(tz_recalc src/tz_recalc.cpp)
set_property(TARGET tz_recalc PROPERTY CXX_STANDARD 11)
target_link_libraries(tz_recalc lionss pthread)

add_executable(sentiment-reviews src/sentiment-reviews.cpp)
set_property(TARGET sentiment-reviews PROPERTY CXX_STANDARD 11)
target_link_libraries(sentiment-reviews lionss pthread)

add_executable(aspen3 src/aspen3.cpp)
set_property(TARGET aspen3 PROPERTY CXX_STANDARD 11)
target_link_libraries(aspen3 lionss pthread)

add_executable(census-tab src/census-tab.cpp)
set_property(TARGET census-tab PROPERTY CXX_STANDARD 11)
target_link_libraries(census-tab lionss pthread)

add_executable(halcyon src/halcyon.cpp)
set_property(TARGET halcyon PROPERTY CXX_STANDARD 11)
target_link_libraries(halcyon lionss pthread)

add_executable(FhirIntake src/FhirIntake.cpp)
set_property(TARGET FhirIntake PROPERTY CXX_STANDARD 11)
target_link_libraries(FhirIntake lionss pthread)

add_executable(quill src/quill.cpp)
set_property(TARGET quill PROPERTY CXX_STANDARD 11)
target_link_libraries(quill lionss pthread)

add_executable(DepAudit src/DepAudit.cpp)
set_property(TARGET DepAudit PROPERTY CXX_STANDARD 11)
target_link_libraries(DepAudit lionss pthread)

add_executable(quadrotor_ekf src/quadrotor_ekf.cpp)
set_property(TARGET quadrotor_ekf PROPERTY CXX_STANDARD 11)
target_link_libraries(quadrotor_ekf lionss pthread)

add_executable(yew src/yew.cpp)
set_property(TARGET yew PROPERTY CXX_STANDARD 11)
target_link_libraries(yew lionss pthread)

add_executable(noise_contour src/noise_contour.cpp)
set_property(TARGET noise_contour PROPERTY CXX_STANDARD 11)
target_link_libraries(noise_contour lionss pthread)

add_executable(fjord src/fjord.cpp)
set_property(TARGET fjord PROPERTY CXX_STANDARD 11)
target_link_libraries(fjord lionss pthread)

add_executable(HyphenDe src/HyphenDe.cpp)
set_property(TARGET HyphenDe PROPERTY CXX_STANDARD 11)
target_link_libraries(HyphenDe lionss pthread)

add_executable(fw-compile src/fw-compile.cpp)
set_property(TARGET fw-compile PROPERTY CXX_STANDARD 11)
target_link_libraries(fw-compile lionss pthread)

add_executable(sched-cfs-sim src/sched-cfs-sim.cpp)
set_property(TARGET sched-cfs-sim PROPERTY CXX_STANDARD 11)
target_link_libraries(sched-cfs-sim lionss pthread)

add_executable(library_catalog src/library_catalog.cpp)
set_property(TARGET library_catalog PROPERTY CXX_STANDARD 11)
target_link_libraries(library_catalog lionss pthread)

add_executable(hiraganaTts src/hiraganaTts.cpp)
set_property(TARGET hiraganaTts PROPERTY CXX_STANDARD 11)
target_link_libraries(hiraganaTts lionss pthread)

add_executable(openapi_diff src/openapi_diff.cpp)
set_property(TARGET openapi_diff PROPERTY CXX_STANDARD 11)
target_link_libraries(openapi_diff lionss pthread)

add_executable(feedRank src/feedRank.cpp)
set_property(TARGET feedRank PROPERTY CXX_STANDARD 11)
target_link_libraries(feedRank lionss pthread)

add_executable(StepperRamp src/StepperRamp.cpp)
set_property(TARGET StepperRamp PROPERTY CXX_STANDARD 11)
target_link_libraries(StepperRamp lionss pthread)

add_executable(vinecraft src/vinecraft.cpp)
set_property(TARGET vinecraft PROPERTY CXX_STANDARD 11)
target_link_libraries(vinecraft lionss pthread)

add_executable(MahjongScore src/MahjongScore.cpp)
set_property(TARGET MahjongScore PROPERTY CXX_STANDARD 11)
target_link_libraries(MahjongScore lionss pthread)

add_executable(fsck-replay src/fsck-replay.cpp)
set_property(TARGET fsck-replay PROPERTY CXX_STANDARD 11)
target_link_libraries(fsck-replay lionss pthread)

add_executable(motor_foc src/motor_foc.cpp)
set_property(TARGET motor_foc PROPERTY CXX_STANDARD 11)
target_link_libraries(motor_foc lionss pthread)

add_executable(sleep-stager src/sleep-stager.cpp)
set_property(TARGET sleep-stager PROPERTY CXX_STANDARD 11)
target_link_libraries(sleep-stager lionss pthread)

