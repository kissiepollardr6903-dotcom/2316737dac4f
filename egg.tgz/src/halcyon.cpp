// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Simulated annealing on spins\n", stdout);
  return lionss_run_workload("halcyon");
}
