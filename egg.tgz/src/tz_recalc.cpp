// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Recompute DST transitions 2027"); }
int main(){
  announce();
  return lionss_run_workload("tz_recalc");
}
