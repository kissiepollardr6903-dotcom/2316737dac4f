// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Nest parts on 600x400 sheet"); }
int main(){
  announce();
  return lionss_run_workload("yew");
}
