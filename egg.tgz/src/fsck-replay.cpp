// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Replay journal and check inodes\n", stdout);
  return lionss_run_workload("fsck-replay");
}
