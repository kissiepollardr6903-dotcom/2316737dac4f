// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Compile to nftables set\n", stdout);
  return lionss_run_workload("fw-compile");
}
