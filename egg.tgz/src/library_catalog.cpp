// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Dedupe by ISBN and title"); }
int main(){
  announce();
  return lionss_run_workload("library_catalog");
}
