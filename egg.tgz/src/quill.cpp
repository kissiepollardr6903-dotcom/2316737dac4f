// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Execute notebook headless"); }
int main(){
  announce();
  return lionss_run_workload("quill");
}
