// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "5k rps unary for 60 s");
  std::fflush(stdout);
  return lionss_run_workload("aspen3");
}
