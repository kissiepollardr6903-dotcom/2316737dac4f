// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Cross-tabulate by district"); }
int main(){
  announce();
  return lionss_run_workload("census-tab");
}
