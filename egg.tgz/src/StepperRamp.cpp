// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("S-curve profile generation\n", stdout);
  return lionss_run_workload("StepperRamp");
}
