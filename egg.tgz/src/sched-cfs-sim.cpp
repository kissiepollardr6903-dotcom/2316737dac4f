// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Simulate 10 s of CFS");
  std::fflush(stdout);
  return lionss_run_workload("sched-cfs-sim");
}
